import ToolCanvas from "./ToolCanvas.js";

const toolCanvasDom = document.getElementById("toolCanvas");

let tool = new ToolCanvas(toolCanvasDom);
// tool.lineIcon();
// tool.rectIcon();
